public class Triangle {
    double base;
    double height;

    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    public double findArea(){
        double area = base * height / 2;
        return area;
    }

    public boolean isSameArea(Triangle t) {
        return findArea() == t.findArea();
//        double area1 = findArea();
//        double area2 = t.findArea();
//        if (area1 == area2) {
//            return true;
//        } else {
//            return false;
//        }
    }
}
