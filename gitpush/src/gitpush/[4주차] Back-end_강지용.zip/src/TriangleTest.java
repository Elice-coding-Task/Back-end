// Press ⇧ twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class TriangleTest {
    public static void main(String[] args) {
        // 1번 문제
        Triangle t = new Triangle(10.0, 5.0);
        System.out.println(t.findArea());

        // 2번 문제
        Triangle t1 = new Triangle (10.0, 5.0);
        Triangle t2 = new Triangle (5.0, 10.0);
        Triangle t3 = new Triangle (8.0, 8.0);
        System.out.println(t1.isSameArea(t2));
        System.out.println(t1.isSameArea(t3));
    }
}