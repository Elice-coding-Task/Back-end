public class MemberTest {
    public static void main(String[] args) {
        Member sMember = new Member("둘리", "드래곤", "1137*", 3900);
        System.out.printf("%s\t%s\t%s\t%d\n", sMember.getName(), sMember.getId(), sMember.getPassword(), sMember.getage());
        sMember.setMember("공실이", "핑크드래곤", "2599#", 4200);
        System.out.printf("%s\t%s\t%s\t%d\n", sMember.getName(), sMember.getId(), sMember.getPassword(), sMember.getage());
    }

}
