public class Car {
    private int numOfCar;
    private int numOfRedCar;

    public int getNumOfCar() {
        return numOfCar;
    }
    public int getNumOfRedCar() {
        return numOfRedCar;
    }


}
