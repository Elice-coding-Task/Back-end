public class Car {
    private static int numOfCar = 0;
    private static int numOfRedCar = 0;
    private String color;

    public static int getNumOfCar() {
        return numOfCar;
    }
    public static int getNumOfRedCar() {
        return numOfRedCar;
    }

    public Car(String color) {
        this.color = color;
        numOfCar ++;
        if (color.equalsIgnoreCase("red")) {
            numOfRedCar ++;
        }
    }


}
