package test.src;

import java.util.Scanner;

public class Multiply {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int total = 0;
        System.out.println("3개의 숫자를 순서대로 입력해 주세요 : ");
        System.out.print("A : ");
        int a = scanner.nextInt();
        System.out.print("B : ");
        int b = scanner.nextInt();
        System.out.print("C : ");
        int c = scanner.nextInt();
        int num = a*b*c;
        int[] array = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        while(num > 0) {
            array[num%10] += 1;
            num /= 10;
        }
        for(int i = 0; i < 9; i++){
            if(array[i] != 0){
                System.out.println((i+1)+"=> "+array[i]+"번 쓰였습니다");
            }
        }
    }
}
