package test.src;
import java.util.Scanner;
public class Week5 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int total = 0;
        System.out.print("0 ~ 99의 정수 중 하나를 입력해 주세요 : ");
        int num = scanner.nextInt();
        while(num > 0) {
            total += num % 10;
            num /= 10;
        }
        System.out.println("각 자리수의 합은 "+total+"입니다");
    }


}
