public class Triangle {
    private double height;
    private double width;

    public Triangle(double height, double width) {
        this.height = height;
        this.width = width;
    }

    /**
     * 넓이 구하기
     * @return area
     */
    public double findArea() {
        return height * width / 2;
    }

    public boolean isSameArea(Triangle triangle) {
        return findArea() == triangle.findArea();
    }



}
