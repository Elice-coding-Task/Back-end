import java.util.ArrayList;

public class Car {
    private String color;
    private static ArrayList<Car> carList;
    private static ArrayList<Car> redCarList;

    public Car (String color) {
        this.color = color;
        if (carList == null) {
            carList = new ArrayList<>();
        }

        carList.add(this);

        if (color.equals("red") || color.equals("RED")) {
            if (redCarList == null) {
                redCarList = new ArrayList<>();
            }
            redCarList.add(this);
        }
    }

    public int getNumOfCar () {
        return carList.size();
    }

    public int getNumOfRedCar () {
        return redCarList.size();
    }

}
