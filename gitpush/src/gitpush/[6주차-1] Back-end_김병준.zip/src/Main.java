import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            int num = scanner.nextInt();

            //2 이하 걸러내기
            if (num <= 2) System.out.println("소수입니다.");

            //제곱근 구하기
            double sqrt = Math.sqrt(num);


            for (int i = 2; i <= sqrt; i++) {
                if (num % i == 0) {
                    System.out.println("소수가 아닙니다.");
                    return;
                }
            }
            System.out.println("소수입니다.");
        } catch (Exception e) {
            System.out.println("math Error");
        }

    }

}
