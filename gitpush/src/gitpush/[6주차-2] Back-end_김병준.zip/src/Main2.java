
public class Main2 {
    public static void main(String[] args) {
        int result1 = 0;
        int result2 = 0;

        for (int i = 1; i <= 10; i++) {
            result1 += Math.pow(i, 2);
            result2 += i;
        }

        System.out.println((int) Math.pow(result2, 2) - result1);
    }

    public static void main2(String[] args) {
        System.out.println(2640);
    }
}
