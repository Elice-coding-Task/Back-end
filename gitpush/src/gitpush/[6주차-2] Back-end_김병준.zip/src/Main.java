import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        int result = 1;
        while (true) {
            num /= 10;
            if (num > 0) result *= 10;
            else break;
        }

        System.out.printf("%d의 자릿수", result);
    }
}
