import java.util.Arrays;
import java.util.Scanner;

public class Main6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("숫자 9개를 입력하세요.");

        int[] in = new int[9];
        for (int i = 0; i < 9; i++) {
            in[i] = scanner.nextInt();
        }

        int max = in[0];
        int maxIndex = 0;

        for (int i = 0; i < in.length; i++) {
            if (in[i] > max) {
                max = in[i];
                maxIndex = i + 1;
            }
        }
        System.out.println("최댓값은 " + max + "이고, " + maxIndex + " 번 째 입니다.");
    }
}
