import java.util.Scanner;

public class Main5 {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("0~9 사이의 숫자를 입력해 주세요.");
        int n = scanner.nextInt();

        if (0 < n && n <= 9) {
            for (int i = 1; i <= 9; i++) {
                int x = n * i;
                System.out.println(n + "*" + i + "=" + x);
            }
        } else {
            System.out.println("0~9 사이의 숫자를 입력해 주세요.");
        }
    }
}