package test.src;

class Member {
    private String name;
    private String id;
    private String password;
    private int age;

    Member(String name, String id, String password, int age){
        this.name = name;
        this.id = id;
        this.password = password;
        this.age = age;
    }

    public void setMember(String name, String id, String password, int age){
        this.name = name;
        this.id = id;
        this.password = password;
        this.age = age;
    }
    String getName(){
        return this.name;
    }

    String getId(){
        return this.id;
    }

    String getPassword(){
        return this.password;
    }

    int getage(){
        return this.age;
    }
}
