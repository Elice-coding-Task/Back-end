package test.src;

public class Triangle {
    public double base ;
    public double height ;

    Triangle(double base, double height){
        this.base = base;
        this.height = height;
    }

    public double findArea(){
        return base*height/2;
    }

    public boolean isSameArea(Triangle triangle){
        return findArea() == triangle.findArea();
    }
}
