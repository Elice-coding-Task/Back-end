package test.src;

public class Car {
    private static int numberOfCar;
    private static int numberOfRedCar;
    Car(String color){
        numberOfCar++;

        color = color.toLowerCase();
        if(color.equals("red") ){
            numberOfRedCar++;
        }
    }

    public static int getNumOfCar() {

        return numberOfCar;
    }

    public static int getNumOfRedCar() {
        return numberOfRedCar;
    }
}
