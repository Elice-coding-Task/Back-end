import java.util.Scanner;
public class Main {
    //1번문제
//    public static void main(String[] args){
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("정수 하나를 입력해 주세요 : ");
//        int input = scanner.nextInt();
//        int n = 0;
//        while(input>0){
//            if(input%10 > 1){
//                n += 1;
//                input /= 10;
//            }
//            else break;
//        }
//        System.out.println((int)Math.pow(10,n-1)+"의 자리수 입니다");
//    }

    //2번문제

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        //문제 주어진 대로 1부터 10까지 스캐너로 다 입력하게 했습니다.
        System.out.println("1부터 10까지의 자연수를 입력해 주세요 : ");
        int sumPow = 0;
        int powSum = 0;
        for(int i = 1; i <= 10; i++){
            int input = scanner.nextInt();
            sumPow += input;
            powSum += (int)Math.pow(input, 2);
            if(i == 10){
                scanner.close();
            }
        }

        System.out.println((int)Math.pow(sumPow, 2) - powSum);
    }
}
