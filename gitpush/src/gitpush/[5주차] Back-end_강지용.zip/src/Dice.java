import java.util.Random;

public class Dice {
    private int side;

    public int roll() {
        return side;
    }

    public Dice() {
        side = (int) (Math.random() * 6) + 1;
    }
}
