import java.io.BufferedReader;
import java.util.Scanner;

public class Main {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        for (int i = 1; i < 10; i++) {
            System.out.printf("%d * %d = %d\n", n, i, n * i);
        }

        scanner.close();
    }

    public static void main2 (String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] line = scanner.nextLine().split(" ");

        int index = 0;
        int max = 0;
        for (int i = 0; i < line.length; i++) {
            int parsedInt = Integer.parseInt(line[i]);
            if (max < parsedInt) {
                max = parsedInt;
                index = i;
            }
        }

        System.out.printf("%d %d", max, index+1);

    }


}
