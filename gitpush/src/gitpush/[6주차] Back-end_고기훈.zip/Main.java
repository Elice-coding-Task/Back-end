import java.util.Scanner;
public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("정수 하나를 입력하세요 => ");
//        String input = scanner.nextLine();
//        boolean isNumeric =  input.matches("[+-]?\\d*(\\.\\d+)?");
//        if(isNumeric){
//            int num = Integer.parseInt(input);
//            for(int i = 2; i < num/2; i++){
//                int remainder = num%i;
//                if(remainder == 0){
//                    System.out.println("소수가 아닙니다!");
//                    break;
//                }
//            }
//            System.out.println("소수입니다!");
//        }
//        else System.out.println("Math error");
//
//    }
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        String[] inputArray = input.split("");
        for(int i = 0; i < inputArray.length; i++){
            boolean isNumeric =  inputArray[i].matches("[+-]?\\d*(\\.\\d+)?");
            if(isNumeric) System.out.print(inputArray[i]);
        }

    }
}
