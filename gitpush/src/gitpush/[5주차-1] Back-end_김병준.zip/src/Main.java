import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int result = 0;
        int goal = scanner.nextInt();

        for (int i = 0; i <= goal; i++) {
            result += i;
        }
        System.out.println(result);
    }
}
