import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int A = scanner.nextInt();
        int B = scanner.nextInt();
        int C = scanner.nextInt();
        scanner.close();

        int result = A * B * C;
        System.out.println(result);

        int[] count = new int[10]; // 0부터 9까지의 숫자가 몇 번 쓰였는지를 저장할 배열

        while (result > 0) {
            int digit = result % 10; // 일의 자리 숫자를 가져옴
            count[digit]++; // 해당 숫자의 카운트를 증가시킴
            result /= 10; // 일의 자리를 제외한 나머지 자리의 수를 얻기 위해 10으로 나눔
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            if (count[i] != 0) {
                sb.append(i).append("이 ").append(count[i]).append("번, ");
            }
        }

        // 마지막 ", " 제거 후 "쓰였다." 추가
        int length = sb.length();
        sb.delete(length - 2, length).append("쓰였다.");


        System.out.println(sb.toString());
    }
}
