import java.util.Scanner;

public class Main {

    public static void main2(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        if (n == 0) {
            print(n);
            return;
        }

        int result = 0;
        while (n > 0) {
            result += n % 10;
            n /= 10;
        }
        print(result);

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int c = scanner.nextInt();

        int abc = a * b * c;
        print(abc);
        char[] result = String.valueOf(abc).toCharArray();
        int[] record = new int[10];
        for (char num : result) {
            record[num - 48]++;
        }

        for (int num : record) {
            print(num);
        }

    }

    public static void print (int n) {
        System.out.println(n);
    }
}
